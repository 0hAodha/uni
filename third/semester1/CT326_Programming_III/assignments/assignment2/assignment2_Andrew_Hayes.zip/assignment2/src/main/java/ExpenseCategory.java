// Name: Andrew Hayes
// ID Number: 21321503
public enum ExpenseCategory {
    TRAVEL_AND_SUBSISTENCE,
    SUPPLIES,
    ENTERTAINMENT,
    EQUIPMENT,
    OTHER
}