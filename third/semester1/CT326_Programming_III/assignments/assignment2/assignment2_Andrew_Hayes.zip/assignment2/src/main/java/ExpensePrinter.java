// Name: Andrew Hayes
// ID Number: 21321503
import java.util.ArrayList;

public interface ExpensePrinter {

    /**
     * method to print the expenses
     * @param expenses
     */
    public void print(ArrayList<Expense> expenses);
}