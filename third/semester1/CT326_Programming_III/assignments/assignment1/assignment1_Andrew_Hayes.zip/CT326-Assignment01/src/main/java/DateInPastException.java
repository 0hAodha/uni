// Andrew Hayes, ID: 21321503
public class DateInPastException extends RuntimeException {
    public DateInPastException(String s) {
        super(s);
    }
}
