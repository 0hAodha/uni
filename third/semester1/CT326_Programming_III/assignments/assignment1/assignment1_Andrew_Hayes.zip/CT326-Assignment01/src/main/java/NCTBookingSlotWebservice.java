// Andrew Hayes, ID: 21321503
import java.time.LocalDateTime;

public interface NCTBookingSlotWebservice {
    public LocalDateTime getBookingDateTime(TestCentre testCentre);
}
