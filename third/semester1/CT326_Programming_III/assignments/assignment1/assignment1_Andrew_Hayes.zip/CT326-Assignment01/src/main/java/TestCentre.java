// Andrew Hayes, ID: 21321503
public class TestCentre {
    private String name;
    private String address;

    public TestCentre(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public String getName() { return name; }
    public String getAddress() { return address; }
}
