-- sql to create the artists and artworks sql tables

DROP TABLE IF EXISTS `artists`;
CREATE TABLE IF NOT EXISTS `artists` (
  `artistId` int(11) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `birthYear` smallint(6) NOT NULL,
  `biography` longtext NOT NULL,
  PRIMARY KEY (`artistId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `artists` (`artistId`, `fullname`, `nationality`, `birthYear`, `biography`) VALUES
(1, "Gustave Dore", "French", 1832, "Paul Gustave Louis Christophe Dore (6 January 1832 – 23 January 1883) was a French printmaker, illustrator, painter, comics artist, caricaturist, and sculptor. He is best known for his prolific output of wood-engravings illustrating classic literature, especially those for the Vulgate Bible and Dante's Divine Comedy. These achieved great international success, and he became renowned for printmaking, although his role was normally as the designer only; at the height of his career some 40 block-cutters were employed to cut his drawings onto the wooden printing blocks, usually also signing the image."),
(2, "Hieronymus Bosch", "Dutch", 1450, "Hieronymus Bosch, born Jheronimus van Aken (c. 1450 – 9 August 1516) was a Dutch/Netherlandish painter from Brabant. He is one of the most notable representatives of the Early Netherlandish painting school. His work, generally oil on oak wood, mainly contains fantastic illustrations of religious concepts and narratives. Within his lifetime his work was collected in the Netherlands, Austria, and Spain, and widely copied, especially his macabre and nightmarish depictions of hell.");

DROP TABLE IF EXISTS `artworks`;
CREATE TABLE IF NOT EXISTS `artworks` (
  `artworkId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `medium` varchar(255) NOT NULL,
  `imageName` varchar(255) NOT NULL,
  `artistId` int(11) NOT NULL,
  PRIMARY KEY (`artworkId`),
  KEY `artistId` (`artistId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `artworks` (`artworkId`, `title`, `description`, `medium`, `imageName`, `artistid`) VALUES
(1, "Triptych of the Temptation of St. Anthony", "The Triptych of Temptation of St. Anthony is an oil painting on wood panels by the Early Netherlandish painter Hieronymus Bosch, dating from around 1501. The work portrays the mental and spiritual torments endured by Saint Anthony the Great (Anthony Abbot), one of the most prominent of the Desert Fathers of Egypt in the late 3rd and early 4th centuries. The Temptation of St. Anthony was a popular subject in Medieval and Renaissance art. In common with many of Bosch's works, the triptych contains much fantastic imagery. The painting hangs in the Museu Nacional de Arte Antiga in Lisbon.", "Oil on panel", "anthony.jpg", 2),
(2, "The Garden of Earthly Delights", "The Garden of Earthly Delights is the modern title given to a triptych oil painting on oak panel painted by the Early Netherlandish master Hieronymus Bosch, between 1490 and 1510, when Bosch was between 40 and 60 years old. It has been housed in the Museo del Prado in Madrid, Spain since 1939.", "Oil on oak panels", "delights.jpg", 2),
(3, "Jacob Wrestling with the Angel", "Jacob wrestling with the angel is described in the Book of Genesis (chapter 32:22–32; also referenced in the Book of Hosea, chapter 12:3–5). The 'angel' in question is referred to as 'man' and 'God' in Genesis, while Hosea references an 'angel' The account includes the renaming of Jacob as Israel (etymologized as 'contends-with-God').", "Wood Engraving", "jacob.jpg", 1),
(4, "Christ Leaving the Praetorium", "Christ Leaving the Praetorium is an oil on canvas painting by French artist Gustave Dore, created between 1867 and 1872. It was the largest of his religious paintings, with 609 by 914 cm, and the painting that he considered to be 'the work of his life'. The painting was a great success, since it was reproduced in engraving in 1877. Dore himself created other replicas. There are two other versions: one, significantly smaller, is on display in the Bob Jones University Picture Gallery in Greenville, in South Carolina, the other, almost as large as the original, is kept in the Musee d'Arts de Nantes.", "Oil on canvas", "christ.jpg", 1);
COMMIT;

