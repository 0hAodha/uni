/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;

/**
 *
 * @author andrew
 */
@Entity
@Table(name = "artworks")
@NamedQueries(
{
    @NamedQuery(name = "Artwork.findAll", query = "SELECT a FROM Artwork a")
})
public class Artwork implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Basic(optional = false)
    @Column(name = "artworkId")
    private Long artworkId;
        
    @Size(max = 255)
    @Column(name = "title")
    private String title;
    
    // descriptiong will likely be quite long so store as blob in db
    @Lob
    @Size(max = 2147483647)
    @Column(name = "description")
    private String description;
    
    @Size(max = 255)
    @Column(name = "medium")
    private String medium;
        
    @Size(max = 255)
    @Column(name = "imageName")
    private String imageName;
      
    // many artworks relate to one artist
    @JoinColumn(name = "artistId", referencedColumnName = "artistId")
    @ManyToOne
    private Artist artistId;
    
    // default empty constructor
    public Artwork() {
        
    }
    
    // id-only constructor
    public Artwork(Long artworkID) {
        this.artworkId = artworkId;
    }

    // full constructor
    public Artwork(Long artworkId, String title, String description, String medium, String imageName, Artist artistId) {
        this.artworkId = artworkId;
        this.title = title;
        this.description = description;
        this.medium = medium;
        this.imageName = imageName;
        this.artistId = artistId;
    }
    
    // getters and setters 
    
    public Long getArtworkId() {
        return artworkId;
    }

    public void setArtworkId(Long id) {
        this.artworkId = artworkId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMedium() {
        return medium;
    }

    public void setMedium(String medium) {
        this.medium = medium;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public Artist getArtistId() {
        return artistId;
    }

    public void setArtistId(Artist artistId) {
        this.artistId = artistId;
    }
}
