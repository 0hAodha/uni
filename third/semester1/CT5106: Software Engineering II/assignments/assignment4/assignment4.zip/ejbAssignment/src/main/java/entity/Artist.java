/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import java.util.Collection;

/**
 *
 * @author andrew
 */
@Entity
@Table(name = "artists")
@NamedQueries(
{
   @NamedQuery(name = "Artist.findAll", query = "SELECT a FROM Artist a")
})
public class Artist implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Basic(optional = false)
    @Column(name = "artistId")
    private Long artistId;

    @Size(max = 255)
    @Column(name = "fullName")
    private String fullName;    // easier to store name as one variable if we never need to handle forename & surname differently
        
    @Size(max = 255)
    @Column(name = "nationality")
    private String nationality;
    
    @Column(name = "birthYear")
    private Short birthYear;
            
    // biography will likely be quite long so store it as blob in db
    @Lob
    @Size(max = 2147483647)
    @Column(name = "biography")
    private String biography;
    
    // one to many relation of artist to artwork
    @OneToMany(mappedBy = "artistId")
    private Collection<Artwork> artworkCollection;
    
    // default empty constructor
    public Artist() {
        
    }
    
    // id-only constructor
    public Artist (Long artistId) {
        this.artistId = artistId;
    }
    
    // full constructor 
    public Artist(Long artistId, String fullName, String nationality, Short birthYear, String biography) {
        this.artistId = artistId; 
        this.fullName = fullName;
        this.nationality = nationality;
        this.birthYear = birthYear;
        this.biography = biography;
    }
    
    // getters and setters

    public Long getArtistId() {
        return artistId;
    }

    public void setArtistId(Long artistId) {
        this.artistId = artistId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public Short getBirthYear() {
        return birthYear;
    }

    public void setBirthYear(Short birthYear) {
        this.birthYear = birthYear;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }
    
    public Collection<Artwork> getArtworkCollection() {
        return artworkCollection;
    }

    public void setArtworkCollection(Collection<Artwork> artworkCollection)
    {
        this.artworkCollection = artworkCollection;
    }
}
