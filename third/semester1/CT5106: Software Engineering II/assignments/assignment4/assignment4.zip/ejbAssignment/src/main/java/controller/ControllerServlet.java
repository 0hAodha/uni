package controller;

import entity.*;
import java.io.IOException;
import java.util.Collection;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import session.ArtistFacade;

@WebServlet(name = "Controller",
        loadOnStartup = 1,
        urlPatterns =
        {
            "/artist",          // for viewing an artist's works
            "/chooseLanguage"   // for switching language
        })
public class ControllerServlet extends HttpServlet
{

    Artist selectedArtist;
    Collection<Artwork> artistArtworks;
    Collection<Artist> artists;

    @EJB
    private ArtistFacade artistFacade;

    @Override
    public void init(ServletConfig servletConfig) throws ServletException
    {
        super.init(servletConfig);
        
        // get list of all artists in db using artist facade
        artists = artistFacade.findAll();

        // store artist list in servlet context
        getServletContext().setAttribute("artists", artists);

    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {

        String userPath = request.getServletPath();
        HttpSession session = request.getSession();

        // if going to an artist's page
        if (userPath.equals("/artist"))
        {

            // get artistId from request
            String artistId = request.getQueryString();

            if (artistId != null)
            {

                // get selected artist by artist id
                selectedArtist = artistFacade.find(Long.valueOf(artistId));

                // place selected artist in session scope
                session.setAttribute("selectedArtist", selectedArtist);

                // get all artworks by the selected artist and put in session scope
                artistArtworks = selectedArtist.getArtworkCollection();
                session.setAttribute("artistArtworks", artistArtworks);

                // forward to artistArtworks.jsp with artworks and artist in session scope
                request.getRequestDispatcher("/artistArtworks.jsp").forward(request, response);
               
               return;
            }
        } 
        // else if setting language
        else if (userPath.equals("/chooseLanguage"))
        {
            // get language choice and put in request scope
            String language = request.getParameter("language");
            request.setAttribute("language", language);
        }

        String userView = (String) session.getAttribute("view");

        // use RequestDispatcher to forward request internally
        String url = "/" + userView + ".jsp";

        try
        {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {

        processRequest(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {

        processRequest(request, response);

    }
}
